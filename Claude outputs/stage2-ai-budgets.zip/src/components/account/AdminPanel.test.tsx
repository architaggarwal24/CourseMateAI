import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { act, cleanup, fireEvent, render, screen, within } from "@testing-library/react";

const auth = vi.hoisted(() => ({ user: null as null | Record<string, unknown> }));
vi.mock("@/contexts/AuthContext", () => ({ useAuth: () => ({ user: auth.user }) }));
const toasts = vi.hoisted(() => ({ success: vi.fn(), apiError: vi.fn(), error: vi.fn() }));
vi.mock("@/components/ui/Toast", async (orig) => ({ ...(await orig<object>()), toast: toasts }));

import AdminPanel from "./AdminPanel";

const STUDENT = {
  user_id: 7, email: "s@example.com", username: "stud", full_name: "Stu Dent", email_verified: true, role: "user", is_owner: false,
  banned: false, ban_reason: null, ban_expires: null, created_at: "2026-11-01T00:00:00Z", tier: "apprentice", tier_name: "Apprentice", plan: null,
};
const AI = { days: 30, today_usd: 0.42, cap_usd: 2, cap_max_usd: 20, can_edit: true, capped: false, total_usd: 3.1, by_day: [],
  models: [{ provider: "gemini", model: "flash", calls: 12, fallbacks: 0, tokens_in: 9000, tokens_out: 3000, cost_usd: 0.42, priced: false }],
  routes: { apprentice: { small: ["workers-ai:x"], strong: ["gemini:flash"] }, scholar: { small: [], strong: [] }, sage: { small: [], strong: [] }, archmage: { small: [], strong: [] } },
  budgets: { plan: { apprentice: 0.25, scholar: null, sage: null, archmage: null }, user: { apprentice: 0.02, scholar: 0.05, sage: 0.1, archmage: 0.2 }, tools: 0.1 },
  budget_today: { "plan:apprentice": { spent_usd: 0.12, reserved_usd: 0 } } };
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { "content-type": "application/json" } });
const sent: { method: string; path: string; body: unknown }[] = [];

beforeEach(() => {
  sent.length = 0;
  Object.values(toasts).forEach((f) => f.mockReset());
  vi.stubGlobal("fetch", vi.fn(async (url: string, init: RequestInit = {}) => {
    const u = new URL(url, "http://localhost");
    const method = init.method ?? "GET";
    const body = init.body ? JSON.parse(String(init.body)) : null;
    sent.push({ method, path: u.pathname + u.search, body });
    if (u.pathname === "/api/v1/admin/users") return json({ users: [STUDENT], total: 1, offset: 0, limit: 25 });
    if (u.pathname === "/api/v1/admin/users/7/plan" && method === "PUT") {
      return json({ ...STUDENT, tier: body.tier, tier_name: "Sage", plan: { tier: body.tier, source: "admin", expires_at: "2026-12-05T00:00:00Z", started_at: "x" } });
    }
    if (u.pathname === "/api/v1/admin/users/7/grant" && method === "POST") {
      return json({ ...STUDENT, game: { level: 4, total_xp: 500, coins: 20 }, granted: { xp: body.xp, coins: body.coins, reason: body.reason || null } });
    }
    if (u.pathname === "/api/v1/admin/invites" && method === "GET") return json({ invites: [] });
    if (u.pathname === "/api/v1/admin/ai" && method === "GET") return json(AI);
    if (u.pathname === "/api/v1/admin/ai" && method === "PUT") return json({ ...AI, cap_usd: body.cap_usd ?? AI.cap_usd, budgets: body.budgets ?? AI.budgets });
    if (u.pathname === "/api/v1/admin/invites" && method === "POST") return json({ code: "SAGE-ABCD2345", tier: "sage", tier_name: "Sage", days: 30, max_uses: 10, uses: 0, usable: true });
    return json({ error: { code: "x", message: "unexpected" } }, 500);
  }));
});
afterEach(() => { cleanup(); vi.unstubAllGlobals(); });

const flush = () => act(async () => { await new Promise((r) => setTimeout(r, 0)); });

describe("AdminPanel", () => {
  it("shows the AI spend and saves a new daily cap", async () => {
    auth.user = { user_id: 1, email: "o@x.io", is_admin: true, is_owner: true };
    render(<AdminPanel />);
    await flush();
    expect(screen.getByText("$0.42", { selector: "b" })).toBeTruthy();
    expect(screen.getByText(/estimated/)).toBeTruthy();
    fireEvent.change(screen.getByLabelText("Daily cap (US $)"), { target: { value: "5" } });
    fireEvent.click(screen.getByRole("button", { name: "Save cap" }));
    await flush();
    expect(sent.find((c) => c.method === "PUT" && c.path === "/api/v1/admin/ai")?.body).toEqual({ cap_usd: 5 });
  });

  it("the cap can't go above the ceiling or be emptied; another admin only sees it", async () => {
    auth.user = { user_id: 1, email: "o@x.io", is_admin: true, is_owner: true };
    render(<AdminPanel />);
    await flush();
    expect(screen.getByText(/up to \$20\.00/)).toBeTruthy();
    for (const value of ["25", ""]) {
      fireEvent.change(screen.getByLabelText("Daily cap (US $)"), { target: { value } });
      fireEvent.click(screen.getByRole("button", { name: "Save cap" }));
      await flush();
    }
    expect(sent.some((c) => c.method === "PUT" && c.path === "/api/v1/admin/ai")).toBe(false);
    expect(toasts.error).toHaveBeenCalledTimes(2);
    cleanup();

    AI.can_edit = false;
    try {
      auth.user = { user_id: 2, email: "h@x.io", is_admin: true, is_owner: false };
      render(<AdminPanel />);
      await flush();
      expect(screen.getByText(/\$2\.00 cap/)).toBeTruthy();
      expect(screen.queryByLabelText("Daily cap (US $)")).toBeNull();
      expect(screen.getByText(/Only the owner changes the cap/)).toBeTruthy();
    } finally { AI.can_edit = true; }
  });

  it("shows each plan's spend today and saves the budgets; empty is no limit, a bad value sends nothing", async () => {
    auth.user = { user_id: 1, email: "o@x.io", is_admin: true, is_owner: true };
    render(<AdminPanel />);
    await flush();
    expect(screen.getByText("Today: $0.12")).toBeTruthy();
    expect((screen.getByLabelText("Apprentice (Free): all users a day") as HTMLInputElement).value).toBe("0.25");
    expect((screen.getByLabelText("Sage: all users a day") as HTMLInputElement).value).toBe("");
    fireEvent.change(screen.getByLabelText("Scholar: each user a day"), { target: { value: "abc" } });
    fireEvent.click(screen.getByRole("button", { name: "Save budgets" }));
    await flush();
    expect(sent.some((c) => c.method === "PUT")).toBe(false);
    expect(toasts.error).toHaveBeenCalledWith(expect.stringContaining("Scholar: each user"));
    fireEvent.change(screen.getByLabelText("Scholar: each user a day"), { target: { value: "0.08" } });
    fireEvent.change(screen.getByLabelText("Free tools a day"), { target: { value: "" } });
    fireEvent.click(screen.getByRole("button", { name: "Save budgets" }));
    await flush();
    expect(sent.find((c) => c.method === "PUT")?.body).toEqual({ budgets: {
      plan: { apprentice: 0.25, scholar: null, sage: null, archmage: null },
      user: { apprentice: 0.02, scholar: 0.08, sage: 0.1, archmage: 0.2 },
      tools: null,
    } });
  });

  it("other admins see the budgets but can't change them", async () => {
    AI.can_edit = false;
    try {
      auth.user = { user_id: 2, email: "h@x.io", is_admin: true, is_owner: false };
      render(<AdminPanel />);
      await flush();
      expect((screen.getByLabelText("Sage: each user a day") as HTMLInputElement).disabled).toBe(true);
      expect(screen.queryByRole("button", { name: "Save budgets" })).toBeNull();
      expect(screen.getByText(/Only the owner changes the budgets/)).toBeTruthy();
    } finally { AI.can_edit = true; }
  });

  it("is for admins only", () => {
    auth.user = { user_id: 1, email: "x@x.io", is_admin: false };
    render(<AdminPanel />);
    expect(screen.getByText("Admins only")).toBeTruthy();
  });

  it("lists accounts and gives one a plan for some days", async () => {
    auth.user = { user_id: 1, email: "o@x.io", is_admin: true, is_owner: false };
    render(<AdminPanel />);
    await flush();
    const row = screen.getByRole("list", { name: "Accounts" });
    expect(within(row).getByText("Apprentice (Free)")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Manage s@example.com" }));
    expect(screen.queryByRole("button", { name: /Make admin/ })).toBeNull();        // only the owner makes admins
    const dialog = within(screen.getByRole("dialog"));
    fireEvent.change(dialog.getByRole("combobox", { name: "Plan" }), { target: { value: "sage" } });
    fireEvent.change(dialog.getByLabelText("Days"), { target: { value: "30" } });
    fireEvent.click(screen.getByRole("button", { name: "Save plan" }));
    await flush();
    expect(sent.find((c) => c.method === "PUT")).toMatchObject({ path: "/api/v1/admin/users/7/plan", body: { tier: "sage", days: 30 } });
    expect(toasts.success).toHaveBeenCalled();
  });

  it("the owner can make admins; bad days are caught before sending", async () => {
    auth.user = { user_id: 1, email: "o@x.io", is_admin: true, is_owner: true };
    render(<AdminPanel />);
    await flush();
    fireEvent.click(screen.getByRole("button", { name: "Manage s@example.com" }));
    expect(screen.getByRole("button", { name: /Make admin/ })).toBeTruthy();
    fireEvent.change(screen.getByLabelText("Days"), { target: { value: "-3" } });
    fireEvent.click(screen.getByRole("button", { name: "Save plan" }));
    expect(screen.getByText(/whole number of days/)).toBeTruthy();
    expect(sent.some((c) => c.method === "PUT")).toBe(false);
  });

  it("creates invite codes", async () => {
    auth.user = { user_id: 1, email: "o@x.io", is_admin: true, is_owner: true };
    render(<AdminPanel />);
    await flush();
    fireEvent.click(screen.getByRole("button", { name: "Create code" }));
    await flush();
    expect(sent.find((c) => c.method === "POST")?.body).toMatchObject({ tier: "sage", days: 30, max_uses: 10, valid_days: null });
  });

  it("the owner gives XP and coins (a minus takes away); other admins don't see it", async () => {
    auth.user = { user_id: 1, email: "o@x.io", is_admin: true, is_owner: true };
    render(<AdminPanel />);
    await flush();
    fireEvent.click(screen.getByRole("button", { name: "Manage s@example.com" }));
    const dialog = within(screen.getByRole("dialog"));
    fireEvent.change(dialog.getByLabelText("XP"), { target: { value: "1.5" } });
    fireEvent.click(dialog.getByRole("button", { name: "Give" }));
    expect(dialog.getByText(/A whole number/)).toBeTruthy();
    expect(sent.some((c) => c.path.endsWith("/grant"))).toBe(false);
    fireEvent.change(dialog.getByLabelText("XP"), { target: { value: "500" } });
    fireEvent.change(dialog.getByLabelText("Coins"), { target: { value: "-30" } });
    fireEvent.change(dialog.getByLabelText("Note (optional)"), { target: { value: "contest" } });
    fireEvent.click(dialog.getByRole("button", { name: "Give" }));
    await flush();
    expect(sent.find((c) => c.path.endsWith("/grant"))).toMatchObject({ path: "/api/v1/admin/users/7/grant", body: { xp: 500, coins: -30, reason: "contest" } });
    expect(toasts.success).toHaveBeenCalledWith("+500 XP, -30 coins for stud");
    cleanup();
    auth.user = { user_id: 2, email: "a@x.io", is_admin: true, is_owner: false };
    render(<AdminPanel />);
    await flush();
    fireEvent.click(screen.getByRole("button", { name: "Manage s@example.com" }));
    expect(screen.queryByRole("heading", { name: "XP and coins" })).toBeNull();
  });
});
